export interface AuthenticationStatus
{
    username:string;
    password:string;
    authenticated:boolean;
}